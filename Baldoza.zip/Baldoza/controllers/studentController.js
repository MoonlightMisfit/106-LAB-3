const db = require('../config/db');

exports.getAll = async (req, res) => {
    const [rows] = await db.query("SELECT * FROM students");
    res.json(rows);
};

exports.getById = async (req, res) => {
    const [rows] = await db.query("SELECT * FROM students WHERE id = ?", [req.params.id]);
    res.json(rows[0] || { message: "Not found" });
};

exports.create = async (req, res) => {
    const { firstName, lastName, age, course } = req.body;
    const [result] = await db.query("INSERT INTO students (firstName, lastName, age, course) VALUES (?, ?, ?, ?)", [firstName, lastName, age, course]);
    res.json({ id: result.insertId, message: "Student created" });
};

exports.updateFull = async (req, res) => {
    const { firstName, lastName, age, course } = req.body;
    await db.query("UPDATE students SET firstName=?, lastName=?, age=?, course=? WHERE id=?", [firstName, lastName, age, course, req.params.id]);
    res.json({ message: "Student updated" });
};

exports.updatePartial = async (req, res) => {
    await db.query("UPDATE students SET ? WHERE id = ?", [req.body, req.params.id]);
    res.json({ message: "Field updated" });
};

exports.delete = async (req, res) => {
    await db.query("DELETE FROM students WHERE id = ?", [req.params.id]);
    res.json({ message: "Student deleted" });
};